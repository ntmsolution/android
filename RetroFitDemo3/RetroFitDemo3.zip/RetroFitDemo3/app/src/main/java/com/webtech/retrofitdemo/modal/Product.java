package com.webtech.retrofitdemo.modal;

import java.util.List;

public class Product {
    public List<information> data;

    public class information{
        public String id,product_title,image1,price;
    }

}
