package com.webtech.sqlitedatabasedemo;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import com.webtech.sqlitedatabasedemo.DB.DBMain;

import java.util.ArrayList;

public class DisplayData extends AppCompatActivity {

    Context c;
    ListView lv;
    DBMain objdb ;
    ArrayList ar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_display_data);

        c = DisplayData.this;
        lv = findViewById(R.id.lv);
        objdb = new DBMain(c);
        ar = new ArrayList();

        SQLiteDatabase db = objdb.getReadableDatabase();
        Cursor cursor = db.rawQuery("select * from user",null);

        if(cursor.getCount()>0){
            while (cursor.moveToNext()){
                int id = cursor.getInt(0);
                String fname = cursor.getString(3);
                String lname = cursor.getString(4);
                String username = cursor.getString(1);
                String password = cursor.getString(2);

                ar.add(id+" "+fname+" "+lname+" "+username+" "+password);
            }

            ArrayAdapter adapter = new ArrayAdapter(c,android.R.layout.simple_list_item_1,ar);
            lv.setAdapter(adapter);
        }
    }
}
